
import { useState } from 'react';
import { Header } from './Components/Header/Header';
import { LoginPage } from './Components/LoginPage/LoginPage';
import { Users } from './Components/Users/Users';

function App() {
  const[isLogget, setIsLogget]= useState(false)

  const LoginHandler=()=>{
    setIsLogget((prevState) =>!prevState)
  }
  return (
    <div className="App">
      <Header />
      {isLogget ? <Users /> : <LoginPage LoginHandler={LoginHandler} />}
    </div>
  );
}

export default App;
