import styled from "styled-components"
export const Header=()=>{
    return (
        <StyledHeader>
            <h1>A Typical Page</h1>
        </StyledHeader>
    )
}

const StyledHeader=styled.header`
    background-color: #700170;
    padding: 20px 20px;
`